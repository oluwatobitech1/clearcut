# Clearcut — video text removal

A web app that uploads a video, detects on-screen text, and inpaints it out
frame by frame with temporal consistency.

## Structure

```
frontend/           plain HTML/CSS/JS upload UI, no build step
backend/
  app/
    main.py          FastAPI — upload + job status endpoints, serves the frontend
    tasks.py         Celery task — runs the pipeline, updates job status
    pipeline.py      the actual ML pipeline (detection + inpainting stubs)
    job_store.py     job status, stored in Redis so API + worker can share it
    celery_app.py    Celery config
  requirements.txt
  docker-compose.yml Redis only
```

## Running it locally

1. **Start Redis** (used as both the Celery broker and the job status store):
   ```
   cd backend
   docker compose up -d
   ```

2. **Install Python deps**:
   ```
   python -m venv venv
   source venv/bin/activate
   pip install -r requirements.txt
   ```
   You'll also need `ffmpeg` on your PATH (`brew install ffmpeg` / `apt install ffmpeg`).

3. **Start the Celery worker** (this is where GPU inference happens):
   ```
   celery -A app.celery_app worker --loglevel=info --concurrency=1
   ```

4. **Start the API** (this also serves the frontend, so there's nothing
   separate to run for the UI):
   ```
   uvicorn app.main:app --reload --port 8000
   ```

5. Open `http://localhost:8000` — upload a short video and watch the job
   status update.

## What's real vs. stubbed right now

- Upload, job queueing, status polling, download, the whole frontend: **fully working**.
- Frame extraction and video re-encoding (with audio remux via ffmpeg): **fully working**.
- Text detection and inpainting (`app/pipeline.py`): **stubbed** — it currently
  passes frames through unchanged. The comments in that file show exactly
  what to install (PaddleOCR for detection, ProPainter for inpainting) and
  how to wire them in. This split lets you confirm the whole upload →
  process → download flow works before taking on the heavier GPU model
  installs.

## Before going further

- **GPU**: ProPainter needs a real GPU (8GB+ VRAM) to run at a usable speed.
  If you're not running your own box, look at GPU rental (RunPod, Modal, etc.)
  for the worker specifically — the API/Redis/frontend don't need a GPU.
- **Video length caps**: add a duration check on upload (e.g. reject anything
  over 60s) before this goes anywhere near real users — processing time
  scales with frame count.
- **Auth**: there's none yet. Anyone who can reach `/api/upload` can queue a
  job. Add auth before deploying publicly.
